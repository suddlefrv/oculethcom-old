<?php include('head.php');?>
<div id="header-holder" class="<?php if(isset($action[0]) && $action[0] =="minecraft" ||  isset($action[0]) && $action[0] =="iletisim" || isset($action[0]) && $action[0] =="hosting" ||isset($action[0]) && $action[0] =="hizmet-sozlesmesi" || isset($action[0]) && $action[0] =="404" || isset($action[0]) && $action[0] =="hakkimizda"):?> inner-header <?php else:?> main-header <?php endif;?> <?php if(isset($action[0]) && $action[0] =="minecraft"):?>  hosting-page <?php elseif(isset($action[0]) && $action[0] =="iletisim"):?> contact-header <?php elseif(isset($action[0]) && $action[0] =="hakkimizda"):?> about-header <?php endif;?>">
    <?php if(isset($action[0]) && $action[0] != "minecraft"):?>
    <div class="bg-animation">
        <div class="graphic-show">
            <img class="fix-size" src="/<?=$realPath?>/assets/images/graphic1.png" alt="">
            <img class="img img1" src="/<?=$realPath?>/assets/images/graphic1.png" alt="">
            <img class="img img2" src="/<?=$realPath?>/assets/images/graphic2.png" alt="">
            <img class="img img3" src="/<?=$realPath?>/assets/images/graphic3.png" alt="">
        </div>
    </div>
    <?php endif;?>
    <nav id="nav" class="navbar navbar-default navbar-full">
        <div class="container-fluid">
            <div class="container container-nav">
                <div class="row">
                    <div class="col-md-12">
                        <div class="navbar-header">
                            <button aria-expanded="false" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="logo-holder" href="/anasayfa">
                                <div class="logo" style="width:120px;height:120px">
                                </div>
                            </a>
                        </div>
                        <div style="height: 1px;" role="main" aria-expanded="false" class="navbar-collapse collapse" id="bs">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="/anasayfa">Ana Sayfa</a></li>
                                <li class="dropdown unity-menu">
                                    <a href="#">Hosting <i class="fas fa-caret-down"></i></a>
                                    <ul class="dropdown-menu dropdown-unity">
                                        <li>
                                            <a class="unity-link" href="https://hostluyo.com/">
                                                <div class="unity-box">
                                                    <div class="unity-icon">
                                                        <img src="/<?=$realPath?>/assets/images/service-icon1.svg" alt="">
                                                    </div>
                                                    <div class="unity-title">
                                                        Web Hosting
                                                    </div>
                                                    <div class="unity-details">
                                                        Paylaşımlı Web Hosting
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="unity-link" href="https://hostluyo.com/">
                                                <div class="unity-box">
                                                    <div class="unity-icon">
                                                        <img src="/<?=$realPath?>/assets/images/service-icon2.svg" alt="">
                                                    </div>
                                                    <div class="unity-title">
                                                        cPanel Reseller
                                                    </div>
                                                    <div class="unity-details">
                                                        PHP Siteleriniz için maksimum performans
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="dropdown unity-menu">
                                    <a href="#">Minecraft <i class="fas fa-caret-down"></i></a>
                                    <ul class="dropdown-menu dropdown-unity">
                                        <li>
                                            <a class="unity-link" href="/minecraft">
                                                <div class="unity-box">
                                                    <div class="unity-icon">
                                                        <img src="/<?=$realPath?>/assets/images/odun1.png" alt="">
                                                    </div>
                                                    <div class="unity-title">
                                                        Standart Minecraft Sunucusu
                                                    </div>
                                                    <div class="unity-details">
                                                        E5-26XX v2 Minecraft Sunucuları
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="unity-link" href="/minecraft/premium">
                                                <div class="unity-box">
                                                    <div class="unity-icon">
                                                        <img src="/<?=$realPath?>/assets/images/odun7.png" alt="">
                                                    </div>
                                                    <div class="unity-title">
                                                        Premium Minecraft Sunucuları
                                                    </div>
                                                    <div class="unity-details">
                                                        R9-59XX Minecraft Sunucuları
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="/iletisim">İletişim</a></li>
                                <li><a href="/hakkimizda">Hakkımızda</a></li>
                                <li class="support-button-holder"><a class="support-button" href="https://oculeth.com/panel">Müşteri Paneli</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
