<?php
include('static/header.php');
?>
<div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">Hizmet Sözleşmemiz</div>
                    <div id="page-icon">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div id="page-content" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="content-holder">
                    <h4>1. Taraflar</h4>
                    <p>1.1 Bu sözleşme hizmetler bölümünde belirtilen hizmetleri (Hizmetler olarak anılacaktır) sağlayan Oculeth Bilişim Hizmetleri ile yeni müşteri kaydı bölümünde belirtilen detayları ile belirtilen kişi/kurum (Müşteri olarak anılacaktır) arasında Oculeth'e ait olan internet adresinde faaliyet gösteren internet sitesinin (Site olarak anılacaktır) kullanımı ve bu site üzerinden satın alınacak bu muhasebe ve faturalandırma Oculeth Bilişim Hizmetleri aşağıda belirtilen madde ve koşullar ile imza altına alınmış sayılacaktır.
                    <br> 

1.2 Taraflar iş bu sözleşmede yazılı bilgilerin doğruluğunu beyan, kabul ve taahhüt etme zorundadırlar.
</p>

                    <h4>2. Konusu </h4>
                    <p>2.1 "İş bu sözleşme müşteri tarafından site üzerindeki işlemlerinde, siparişlerinde, gönderdiği mesajlarında kayıt işleminde vermiş olduğu bilgiler doğrultusunda yapmaya ve yapmamaya izni olan bölümleri, siparişlerinde tercihleri uyarınca alacağı hizmetler karşılığında Oculeth'ye ödeyeceği ücretleri düzenleyecektir. Bu hizmet ve işlem açıklamaları aşağıdaki gibidir. <br>2.2 Üyelik bilgileri müşteri tarafından üye olunma sırasında girilen bilgilerdir. Bu bilgiler yapılan işlemlerde baz alınacağından müşteri ve üyenin bu bilgileri hatasız, eksiksiz ve doğru girdiği varsayılmaktadır.  </p>
                    <h4>3. Sorumluluklar</h4>
                    <p>3.1 Oculeth Bilişim Hizmetleri, müşterinin talebi üzerine sipariş olarak ilettiği hizmetleri sağlayacaktır. Siparişin kabulü mesajı ile Oculeth ilgili ücreti tahsil ettiğini kabul edip söz konusu siparişte belirtilen hizmeti vereceğini taahhüt edecektir.  
                    
                    
                    <br>3.2 Ödeme şekli, KDV farkları sipariş sırasında çıkartılacak toplam miktar ile belirtilerek müşterinin aylık veya yıllık ödeme tercihlerine göre ödemesi gereken ücretler Oculeth tarafından bildirilecektir. Ürünün ya da ürünlerin yer aldığı satış sayfasının altında KDV dahil ibaresi var ise sistem KDV'yi hesaplamadan siparişi tamamlayacaktır. <br> 
                    
<br>
3.3 Sipariş kabulü ve işlemlerin onaylanmasından sonra Oculeth müşteri siparişi detayında bulunan hizmete ilişkin Kontrol Paneli, FTP, SQL, E-Mail, Kullanıcı Adlarını ve Şifrelerini müşteriye iletecek ve hizmet başlamış olacaktır. İlgili hesapların ve şifrelerin sorumluluğu müşterinin sorumluluğunda olup bu konulardan doğabilecek zarar ve ziyandan müşteri sorumlu olacaktır.
<br>
3.4 Müşteri aldığı hizmet dahilinde Oculeth tarafından aldığı beyan ve uyarılara uyacağını taahhüt eder. Müşteri, Hosting hesabından faydalanırken Oculeth tarafından yayınlanan her türlü ihtar ya da bildirime uymayı beyan, kabul ve taahhüt eder. Müşteri almış olduğu bulundurma hizmetinde kendisine ücretsiz ve sınırsız olarak verilen hizmetleri yine ücretli ya da ücretsiz ve/veya sınırla ya da sınırsız olarak üçüncü kişilere dağıtamaz, satamaz.
<br>
3.5 Müşteri, hizmet dahilinde sahip olduğu yazılım ve programları kullanarak erişim hakkı bulunmayan dosya veya programlara erişmemeyi, bu tarz bir sorundan dolayı herhangi bir problem yaratmamayı, oluşabilecek sorun ve problemlerde zararı karşılamayı taahhüt eder.
<br>
3.6 Müşteri, Alan Adı, Hosting veya aldığı hizmetlerin kullanılması sırasında yürürlükte olan veya sözleşme süresince yürürlüğe girecek olan vergi, harç ve benzer yükümlülüklerin kendisine ait olduğunu ve karşılayacağını kabul ve taahhüt eder.
<br>
3.7 Müşteri hizmeti dahilinde barındırdığı tüm dosya, doküman ve programlardan, web sitesi ve e-posta hizmetleri ile kullanacağı ve faydalanacağı tüm işlemlerden kendisi sorumlu olduğunu, söz konusu veri, bilgi ve beyanların yasalara aykırılığından doğabilecek tüm hukuki ve cezai sorumluluğu kendisi karşılamayı kabul ve taahhüt eder. İş bu konuda doğabilecek sorunlardan Oculeth'ye herhangi bir kusur iletilemez. Oculeth, sayfaların gönderilmeden önce gözden geçirmez, doğrulamaz, ciro etmez veya kullanıcı tarafında yapılmış sayfalar için herhangi bir şekilde sorumluluk almaz. Oculeth, kullanıcı hesaplarını bu ana hatları ihlal ettiği için, başka bir sebeple veya Oculeth'nin kendi veya kullanıcılarından herhangi birinin işine zararlı olduğuna inandığı için fesih edebilir. Oculeth hukuka aykırılık teşkil eden fiilleri ve eylemleri öğrendiğinden itibaren müşteriye haber vermeden silmek hakkına sahiptir.
<br>
3.8 Oculeth sağladığı hizmet içerisinde bulunan müşteri verilerinin hatalı kullanımlarından, veri içeriklerinden, E-Mail ile kullanılan tüm verilerden doğabilecek hiçbir maddi veya manevi zararlardan sorumlu tutulamaz. Bu verilerin yedekleme ve saklama yükümlülükleri müşteriye aittir. Oculeth müşterinin tüm verilerini düzenli bir biçimde yedekleme ve bakım işlemine tabii tutacaktır. Buna rağmen Oculeth hizmetlerinde meydana gelebilecek kesinti veya veri kaybından dolayı oluşabilecek hatalardan, zarardan ve ziyandan Oculeth sorumlu değildir. Verilerin yedeklenmesi sözleşme metninde aksi belirtilmediği sürece müşterinin sorumluluğundadır.
<br>
3.9 Oculeth müşteri tarafından sipariş verilmiş ve ödemesi sorunsuz olarak gerçekleştirilmiş domain adı tescil işlemlerini yürütecektir. Tescil edilen ve sipariş ile kabul edilen tescil talebi ile ücreti ödenen domain alan adının sahibi müşteridir. Oculeth bu konuda müşterinin talepleri doğrultusunda domain adı üzerinde işlem yapabilecektir. Müşteri tarafından domain adı üzerinde bir düzenleme, değişiklik ve transfer taleplerini en kısa sürede yapacaktır.
<br>
3.10 Müşteri firmayı karalama, olumsuz eleştirme, internet ortamında ya da başka platformda bu tarz kampanyalar düzenlemesi taktirinde hesap sorgusuz ve sualsiz sunuculardan silenecek ve firmamız hiçbir sorumluluk kabul etmeyecektir.
<br>
3.11 Müşteri, aldığı hizmetin faturasını istediği zaman kargo ücretini ödemekle yükümlüdür, eğer kargo ücretini ödemeyi kargoyu geri çevirir ise kargo ücreti müşterinin paneline fatura o olarak yansıtılır. Eğer müşteri yansıtılan faturayı ödememekte ısrar ederse fatura içeriğindeki ürün ve hizmetler fatura ödenene kadar bloke edilir.
<br>
3.12 Müşteri bizden kaynaklanmayan yazılımsal bir sorun yaşadığı taktirde firmamızı sorumlu tutamaz. Sunucu hizmetleri unmanaged olarak sağlanmaktadır, tüm sorumluluk müşteriye aittir.
<br>
3.13 Müşteri, siparişini verdiği hizmetin ödemesini yaptıktan sonra en geç 48 saat içerisinde hizmetini teslim alacaktır. Eğer bu süre içerisinde hizmetini teslim alamaz ise, talep ederse ödemesini geri talep edebilecektir.
<br>
                    <h4>4. Süre </h4>
                    <p>
    <br>
    4.1 İş bu sözleşme sipariş ve ödeme işlemlerinin internet ortamından Oculeth'ye iletilmesi ile birlikte tarafların belirtilen hak ve yükümlülükleri başlar.
 <br>
    4.2 Sözleşme süresi müşterinin ilgili hizmet için sipariş sırasında seçmiş olduğu ödeme periyodu kadardır.
 <br>
    4.3 Taraflar sözleşmenin sona ermesinden 10 iş günü öncesine kadar sözleşmenin süre sonunda sona ereceğini ihtar etmemişler ise sözleşme aynı şart ve hükümler ile önceki sözleşme süresi kadar uzar. (Ücret hususunda meydana gelen değişiklikler saklıdır.)
 <br>
    4.4 cPanel Hosting, Reseller Hosting, VDS Sunucu, Performans VDS Sunucu ödeme onayı sonrası sistem tarafından otomatik olarak aktif edilmektedir. Fiziksel Sunucu, IPv4 Hizmetleri ve Sunucu Barındırma özel kurulum gerektirdiğinden dolayı belirli sürelerin altında kurulması mümkün olmadığından 48 saat içerisinde teslim edilmektedir. Yoğunluğa bağlı olarak hizmet teslim süresi uzayabilmekte veya kısalabilmektedir. Ortalama hizmet teslim süremiz 2 saattir.
</p>
                    
                    </p>
                    <h4>5. Ücret </h4>
                    <p>
                        
<br>
    5.1 İş bu sözleşmede belirtilen hizmetler karşılığı olarak ödenecek ücret sipariş sırasında belirtilen miktar kadardır. Belirtilen ücretlere KDV dahil değil ise sonradan dahil edilerek hesaplanır ve müşteriye gösterilere tahsil gerçekleşir.
<br>
    5.2 Oculeth önceden haber vermeksizin fiyatlar ve tarifeler üzerinde ileriye dönük olarak değişiklik yapma hakkını saklı tutar. Müşteri iş bu değişiklikler konusunda şimdiden oluşabilecek değişiklikler kabul, beyan ve taahhüt eder.
<br>
    5.3 Ücret eğer döviz kuru cinsinden verilmiş ise fatura tarihindeki Merkez bankası efektif satış kuru üzerinden Türk Lirasına çevrilerek ödenir.
<br>
    5.4 Ücret fatura kesim tarihinden itibaren 2. iş günü sonuna kadar sipariş işlemi sırasında kredi kartı ile ödeme talimatı var ise kredi kartı hesabından, kredi kartı ile ödeme talimatı yok ise müşteri iletişim adresinde belirtilen banka hesap numaralarına veya Oculeth elden ödemekle yükümlüdür.
<br>
    5.5 Ödemenin gecikmesi durumunda Oculeth kur farkı faturası kesme hakkını saklı tutar.
<br>
    5.6 Oculeth müşteri ödeme işlemi tamamlayıncaya kadar ilgili hizmeti kapatma, açma hakkını saklı tutar.
<br>
    5.7 Sipariş esnasında belirtildiği gibi domain/alan adı, SSL Sertifikaları ve sunucu hizmetlerinde (Co-Location, Dedicated, Sanal Sunucular) geri ödeme yapılmaz.

                        
                    </p>
                    <h4>6. Askıya Alınma</h4>
                    <p>
                        
<br>
6.1 Ödeme konusunda problem yaşanması, kredi kartı ile ödeme talimatı olan müşterilerde karşılık sorunları veya Hüküm ve Yükümlülükler ile ilgili maddelerden dolayı Oculeth, müşteriye verilen hizmetlerin tümünü, E-Mail, Web, FTP Hesaplarının tamamını durdurma hakkını saklı tutar.
<br>
6.2 Bu durumun devam süresince müşteri adına E-Mail, Web, FTP Erişimleri yapılamaz ve E-Mail hesapları bloklanarak gelen E-Mailler geri çevrilir.
<br>
6.3 Sunucu üzerinde site başına en fazla CPU ve Ram kullanım oranı paket dahilinde izin verilen kadardır. Bu oranı geçen kullanımlarda ilk uyarının ardından ilgili kullanımı yapan site askıya alınır. CPU oranlarını geçen internet siteleri ya da hizmetleri, Oculeth'nin zor durumda kaldığı durumlarda müşteriye haber vermeksizin kapatması ya da iptal etmesi hakkına sahiptir. 5 dakikadan daha az sürede bir "cron" çalıştıramaz. Tüm hosting paketlerinde 100% olarak sistem aktifliğini riske sokacak CPU kullanımında hesabınız ilgili site Suspend edilir. Hosting hizmetleri dosya arşivleme amaçlı kullanılamaz.
<br>
6.4 Sunucularımız üzerinde telif hakları gerek T.C. yasalarına aykırı içerik bulundurmak yasaktır. Bu içeriğe; Bruteforce-Spam-DDoS, Hack, Crack, Warez, Adult ve her türlü telif hakkı içeren dosyalarda dahildir.
<br>
6.5 Sunucu üzerindeki tüm yazılımların güvenliği müşterilerimize aittir. CHMOD 777'den kaynaklanabilecek ya da yazılımınız ile ilgili kaynaklanabilecek herhangi bir konuda hiçbir şekilde Oculeth sorumlu değildir.
<br>
6.6 Müşteri sunucu hizmetlerinde belirtilen ödeme tarihinde faturasını ödememesi durumunda hizmet 2 gün boyunca askıda bekletilir. 3. gün sonunda olacaklardan Oculeth sorumlu değildir.
<br>
6.7 Sunucularımız üzerinden DDoS saldırısı yapılması yasaktır, böyle bir durumun tespitinde Oculeth müşteriye sormaksızın hizmeti iptal etme hakkında sahiptir.
<br>
6.8 Firmamızda bulunan hizmetlerde barındırılması yasak olan sistemler (dosyalar):
<br>
Bu dosyaların hizmetlerde kullanıldığı saptanırsa Oculeth Bilişim Hizmetleri bu hizmeti koşulsuz şartsız durdurmaya hak kazanır. Durdurulan hizmetlerin geri iadesi yapılmaz.
<br>
1. Toplistler 2. *****, erotizm ve pornografi içeren siteler /
<br>
Yasalara aykırı içerik siteleri.
<br>
3. İzinsiz yazılım / *****
<br>
4. Autosurf / PTC / PTS / PPC siteleri.
<br>
5. IP tarayıcıları (IP Scanner).
<br>
6. Bruteforce Programları / Betikleri / Uygulamaları.
<br>
7. E-Posta Bombalama / Spam Betikleri.
<br>
8. Escrow / Banka Benzeri Siteler.
<br>
9. HYIP vb. siteler.
<br>
10. Yasal dağıtım hakkına sahip olmadan herhangi bir materyalin satışını yapmak.
<br>
11. Prime Bank Programları.
<br>
12. Aldatıcı / Fake Sistemler.
<br>
13. Şans / Loto / Kumar Oyunları Siteleri (Teşvik Edenler Dahil).
<br>
14. MUD / RPG veya PPBG’ler.
<br>
15. Diski Zorlayan Programlar.
<br>
16. Nefret İçeren / Irkçı / Rahatsızlık Veren Siteler. 17. Yasa dışı Aktiviteleri Organize Eden Siteler.
<br>
18. Yasa dışı, Telif Hakkı Gerektiren Bağlantı İçeren (*****) Forumlar / Web Sayfaları.
<br>
19. Mailer Pro vb.
<br>
                    </p>
                    <h4>7. Fesih</h4>
                    <p>
                        
<br>
    7.1 Müşteri iş bu sözleşmenin herhangi bir maddesine aykırı davranarak sorumluluklarını ve taahhütlerini yerine getirmediği taktirde ya da iş bu sözleşmenin ön yüzünde beyan ettiği bilgilerin doğru olmadığının tespiti halinde, yukarıda belirtilen sözleşmeyi askıya alma halinin 3 günden fazla devam etmesi halinde, Oculeth hiçbir ihtar ve ihbara gerek kalmaksızın sözleşmeyi tek taraflı olarak fesih etme hakkına sahiptir. Bu şekilde gerçekleşecek fesih sonrasında müşteri; kalan süreye bakılmaksızın ödemiş olduğu son sözleşme ücretini geri istemeyeceğini, fesih tarihinde yürürlükte olan emsal sözleşme bedelinin 5 katı ticari cezai tazminat ödemeyi beyan, kabul ve taahhüt eder.
<br>
    7.2 Müşteri hiçbir gerekçe göstermeksizin sözleşme normal süre ile sona ermeden 10 gün önce yazılı olarak ihtar etmek şartı ile iş bu sözleşmeyi süresi sonunda fesih etme hakkına sahiptir. Sözleşmenin sona erme süresinden önce müşteri tarafından fesih edilmesi halinde sözleşme sonuna kadar ödenecek olan ücretlerin 1/2'sini defaten ve peşin olarak ödemeyi beyan, kabul ve taahhüt eder.
<br>
                    </p>
                    <h4>8. İletişim ve Bilgi Adresleri </h4>
                    <p>
<br>
    8.1 Taraflar konusu sözleşmeden kaynaklanan her türlü tebligat için sipariş adresinde belirtilen posta adreslerine yasal ikametgah olarak kabul, beyan ve taahhüt etmişlerdir.
<br>
    8.2 Bu adreslere yapılan her türlü tebligat tarafların eline ulaşmasa bile tebliğ edilmiş kabul edilecektir. İş bu adreslere ait değişiklikler diğer tarafa yazılı olarak bildirilmedikçe eski adresler geçerli olacaktır.
<br>
    8.3 Oculeth sözleşme süresi içinde müşterinin beyan ettiği elektronik posta adresine mesaj, bilgi, yazı, ihtar, ödeme bildirimi, hesap hareket çizelgesi,hesap ekstresi gönderebilir. Müşteri söz konusu elektronik iletilerin alınmadığı ya da kendisine ulaşmadığı iddiasında bulunamayacağı gibi, söz konusu iletilerin gönderildikleri tarihten 1 gün sonra yasal anlamda tebliğ etmiş sayılacağını beyan, kabul ve taahhüt eder.
<br>
</p>
                <h4>9. Ücretin Ödenmesinde Tereddüt Düşülmesi</h4>
                <p>
<br>
    9.1 Müşteri, aldığı hizmetlere karsılık başvuru tarihini takip eden 7 gün içinde ödeme gerçekleştirmediği takdirde temerrüde düşmüş sayılır. Bu durumda Oculeth kur farkı faturası kesebileceği gibi dilerse fatura tarihinden itibaren aylık %25 gecikme faizi talep edebilir. Müşteri bu gecikme faizi ve kur farkı faturasını ödemeyi beyan ve kabul eder.
<br>
    9.2 Müşteri, is bu sözleşmeden doğan her tür alacak için Oculeth’nin dava ya da icra takibi açması halinde de aylık %25 gecikme faizi, bakiye borç miktarının %50'si kadar cezai şart, %10'u Avukatlık Ücreti ve diğer tüm yasal giderleri ödemeyi beyan, kabul ve taahhüt eder.
<br>
    9.3 Müşteri, is bu sözleşmeden doğan alacaklarının tahsili için yasal mercilere İhtiyati Haciz ve İhtiyati tedbir için başvurması halinde Oculeth'nin teminatsız İhtiyati Haciz ve İhtiyati Tedbir kararı almaya yetkili olduğunu ancak buna rağmen Mahkemelerce teminat istenildiğinde, Bankalardan alınacak teminat mektuplarından doğacak komisyon ve her türlü ücretin kendileri tarafından ödeneceğini ve bu konulara hiçbir itirazda bulunmayacağını beyan, kabul ve taahhüt eder.
<br>
    9.4 Alınan hizmete ilişkin ödemenin, ödeme zamanında yapılmadığı takdirde, Oculeth'nin bu hizmeti bilgi vermeksizin durdurma hakkında sahip olduğu gibi; son ödeme tarihinden 1 hafta süre içinde ücretin ödenmediği durumlarda hizmetin komple geri dönüşümsüz olarak silme hakkına da sahipliği mevcuttur. Bu uygulamaya tabii tutulmuş müşteriler yedek ve hizmetin açımı gibi taleplerde bulunmamayı kabul ederler.
<br>
</p>
                <h4>10. Hosting Hizmeti Kullanım Koşulları</h4>
                <p>10.1 Hosting sunucularında (Paylaşımlı sunucularda) herkesin eşit haklara sahip olması için her müşteri en fazla paket özelliklerinde belirtilen CPU kullanma hakkına sahiptir. Hosting kapasitesi dışında işlem yapan website'ler uyarılarak veya uyarılmadan suspend edilir. Bundan doğan zararlardan Oculeth sorumlu tutulamaz. <br></p>
                <h4>11. Geri İade Koşulları</h4>
                <p>
<br>
    11.1 Oculeth'nin kabul gördüğü geri iade isteklerinden, müşteri iade faturası kesemiyor ise KDV oranı kadar kesinti yapar ve banka havale/eft ücretini kestikten sonra kalan ücreti iade eder.
<br>
    11.2 Müşteri; sistem üzerine yüklediği kredi ya da uzatmak maksadıyla yaptığı sonraki ay/yıl ödemelerini geri iade talep edemez.
<br>
    11.3 Yalnızca Türkiye lokasyon üzerinden sunulan Hosting hizmetleri için 48 saat (2 gün) iade süresi verilir. Bu süre içinde iade alınır bu süre sonrası iade talepleri kabul edilmez.
<br>
    11.4 Müşteri; alan adı, sunucu, yazılım, lisans ve diğer hizmetlerde geri iade talep edemez.
<br>
    11.5 Geri iade isteği yapıldığı takdirde, Oculeth bu isteği en erken 5 gün en geç 1 ay içerisinde gerçekleştirme hakkını, şirketin o anki kararına bağlı olarak saklı tutar.
<br>
    11.6 Kampanyalı hiçbir üründe kesinlikle geri iade yapılmamaktadır.
<br>
    11.7 Yapılan kampanyalar sonucunda firmamız kampanyayı durdurma, değiştirme, fiyat değişikliği yapma hakkını müşteriye bildirmeksizin gerçekleştirme durumunu saklı tutar.
<br>
</p>
                <h4>12. Arıza Durumları </h4>
                <p>
<br>
    12.1 Sunucular elektronik olarak çalışan cihazlar olduğundan dolayı gerekli ve optimal şartlar ne kadarsağlanırsaa da arıza yapma riskleri bulunmaktadır. Arızalanan sunucuların yedek parça temini veri merkezi tarafından yapılmaktadır.
<br>
    12.2 Sunucu da çıkan arızalı parçaları ve yedek parçaları temin süresinden doğacak zararlardan firmamız sorumlu değildir. Hizmet alan şahıs bu süre zarfında firmadan hiçbir hak talep edemez. Yeni parçanın ve arızalı parçanın kendisine temin edilene kadar beklemek zorundadır.
<br>
    12.3 Raid konfigürasyonundan kaynaklı hatalardan kurtarılamaz veri konumuna düsen diskler için kurtarma işlem yapılamamaktadır. Bu durumda raid yeniden kurularak yedekleriniz varsa yedekleriniz yüklenir. Raid konfigürasyonu ve yazılımsal hatalardan firmamız sorumlu değildir.
<br>
    12.4 Sunucu hizmetleriyle verilen managed hizmetlerde yapılan hatalarda firmamız yaşadığınız veri kaybı veya yaşadığınız zararlarda mesuliyet kabul etmemektedir.
<br>
    12.5 Sunucu hizmetlerinde yapılacak veri merkezi veya IP değişikliklerinde sunucuların kapalı duruma gelmesinden firmamız sorumlu tutulamaz. Taşımalarda cihazların aktif hale gelme süresi en az 2, en fazla 5 iş günüdür.
<br>
</p>
                <h4>13. Yetkili Mahkeme ve İcra Daireleri</h4>
                <p>
<br>
    13.1 Yıllık hizmet alan müşterilerimizin Yıl içerisinde ki enflasyon oranındaki değişiklikler nedeniyle ek fatura çıkartılabilmektedir.
<br>
    13.2 İş bu sözleşmenin uygulanması sırasında doğacak her türlü uyuşmazlıkların Çözümünde İzmir Mahkemeleri ve İcra Daireleri yetkilidir.
</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('static/footer.php');
?>