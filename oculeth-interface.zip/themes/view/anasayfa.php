<?php include('static/header.php');?>
<div id="top-content" class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div id="main-slider">
                        <div class="slide">
                            <div class="noti-holder">
                                <a href="/minecraft/premium">
                                    <div class="noti">
                                        <span class="badge">Yeni</span><span class="text">Ryzen işlemcilerimiz aktif.</span>
                                    </div>
                                </a>
                            </div>
                            <div class="spacer"></div>
                            <div class="big-title">Yeni nesil <span>sunucu</span><br>deneyimi.</div>
                            <p>Türkiye'nin En Büyük Oyun Sunucu Sağlayıcısı.</p>
                            <div class="btn-holder">
                                <a href="/panel" class="ybtn ybtn-accent-color ybtn-shadow">Hemen Bir Sunucu Sahibi Ol</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <img class="header-graphic" src="images/graphic1.png" alt="" />
                </div>
            </div>
        </div>
    </div>
</div>
<div id="more-features" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">Güvendesiniz.</div>
                <div class="row-subtitle">Memnuniyetiniz tamamen garantilidir.</div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="mfeature-box">
                    <div class="mfeature-icon">
                        <i class="htfy htfy-trophy"></i>
                    </div>
                    <div class="mfeature-title">Yedekli Altyapı</div>
                    <div class="mfeature-details">Yedekli alt yapımız sayesinde müşterilerimiz doğacak sorunlardan etkilenmiyor.</div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="mfeature-box">
                    <div class="mfeature-icon">
                        <i class="htfy htfy-like"></i>
                    </div>
                    <div class="mfeature-title">Yüksek Performans!</div>
                    <div class="mfeature-details">%100 NVMe SSD disk sahip olan sunucularımız ile okuma/yazma hızını 15 katına çıkardık.</div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4">
                <div class="mfeature-box">
                    <div class="mfeature-icon">
                        <i class="htfy htfy-cogwheel"></i>
                    </div>
                    <div class="mfeature-title">Kesintisiz Ticket Desteği</div>
                    <div class="mfeature-details">7/24 destek ekibimiz ile müşterilerimize kesintisiz hizmet vermekteyiz.</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="testimonials" class="container-fluid">
    <div class="bg-color"></div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="row-title">Müşteri yorumları</div>
                <div class="row-subtitle">Müşterilerin bizim hakkımızda söyledikleri...</div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div id="testimonials-slider">
                    <?php foreach($customer as $rc):?>
                    <div>
                        <div class="details-holder">
                            <img class="photo" src="<?=$rc["img"]?>" alt="">
                            <h4><?=$rc["user"]?></h4>
                            <h5><?=$rc["rank"]?></h5>
                            <p><?=$rc["comment"]?></p>
                        </div>
                    </div>
                    <?php endforeach;?>                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('static/footer.php');?>