<div id="ifeatures" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">Bizi özel kılan nedir ?</div>
                <div class="row-subtitle"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <img src="/<?=$realPath?>/assets/images/feature1.png" alt="">
                    </div>
                    <div class="feature-title">Yedekli Altyapı</div>
                    <div class="feature-details">Yedekli alt yapımız sayesinde müşterilerimiz doğacak sorunlardan etkilenmiyor.</div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                    <img src="/<?=$realPath?>/assets/images/feature2.png" alt="">
                    </div>
                    <div class="feature-title">Yüksek Performans!</div>
                    <div class="feature-details">%100 NVMe SSD disk sahip olan sunucularımız ile okuma/yazma hızını 15 katına çıkardık.</div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                    <img src="/<?=$realPath?>/assets/images/feature3.png" alt="">
                    </div>
                    <div class="feature-title">Kesintisiz Ticket Desteği</div>
                    <div class="feature-details">7/24 destek ekibimiz ile müşterilerimize kesintisiz hizmet vermekteyiz. </div>
                </div>
            </div>
        </div>
    </div>
</div>