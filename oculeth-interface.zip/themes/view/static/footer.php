<div id="message2" class="container-fluid message-area normal-bg boxed">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6">
                <div class="text-other-color1">Hazır Mısın?</div>
                <div class="text-other-color2">Aradığın sunucuyu almak için son adım.</div>
            </div>
            <div class="col-sm-12 col-md-6">
                <div class="buttons-holder">
                    <a href="https://oculeth.com/panel/register.php" class="ybtn ybtn-accent-color">Hemen bize katılın</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="footer" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-sm-4 col-md-3">
                <div class="address-holder">
                    <div class="email"><i class="fas fa-envelope"></i> destek@oculeth.com</div>
                    <div class="address">
                        
                        <div><i class="fas fa-map-marker"></i> ESENTEPE MAH. EVLİYA ÇELEBİ SK. AYDIN APT Kapı No:8/4 KARTAL-İSTANBUL</div>
                    </div>
                    <div class="address">
                        
                        <div><i class="fas fa-map-marker"></i> Vergi No: 8690888253</div>
                        <div><i class="fas fa-map-marker"></i> Vergi Dairesi: Kartal</div>
                    </div>
                </div>
            </div>
            <div class="col-xs-6 col-sm-2 col-md-2">
                <div class="footer-menu-holder">
                    <h4>Kurumsal</h4>
                    <ul class="footer-menu">
                        <li><a href="/hakkimizda">Hakkımızda</a></li>
                        <li><a href="/iletisim">İletişim</a></li>
                        <li><a href="/kurumsal/bilgiler">Kurumsal Bilgiler</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-xs-6 col-sm-2 col-md-3">
                <div class="footer-menu-holder">
                    <h4>Ürünler</h4>
                    <ul class="footer-menu">
                        <li><a href="/hosting/cpanel">Web Hosting</a></li>
                        <li><a href="/hosting/reseller">Reseller Hosting</a></li>
                        <li><a href="/minecraft">Minecraft Standart</a></li>
                        <li><a href="/minecraft/premium">Minecraft Premium</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-xs-12 col-sm-1 col-md-1">
                <div class="social-menu-holder">
                <h4>Discord</h4>
                <iframe src="https://discord.com/widget?id=912122212117524490&theme=dark" width="350" height="250" allowtransparency="true" frameborder="0" sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/<?=$realPath?>/assets/js/jquery.min.js"></script>
<script src="/<?=$realPath?>/assets/js/bootstrap.min.js"></script>
<script src="/<?=$realPath?>/assets/js/bootstrap-slider.min.js"></script>
<script src="/<?=$realPath?>/assets/js/slick.min.js"></script>
<script src="/<?=$realPath?>/assets/js/main.js"></script>
</body>
</html>