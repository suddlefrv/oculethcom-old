<?php
include('static/header.php');
?>
<div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">404</div>
                    <div id="page-icon">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="info-text grey-text">Bir zaman makinesine sahip değilseniz bu sayfayı görüntüleyemezsiniz. (404) bip bop.<br>Ana sayfaya dönmek için tıklayın.</div>
                <div class="btn-holder">
                    <a href="/anasayfa" class="ybtn ybtn-accent-color ybtn-shadow">Ana Sayfa</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('static/footer.php');
?>