<?php
include('static/header.php');
?>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">İletişim</div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="text">Ürün ve hizmetlerimiz hakkında daha detaylı bilgi almak için E-Posta, Canlı Destek veya Telefon aracılığı ile rahatlıkla irtibat sağlayabilirsiniz.</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="contact-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">İletişim Adreslerimiz</div>
                <div class="row-subtitle"></div>
            </div>
        </div>
        <div class="row">
        <div class="col-md-4">
                <div class="info-box">
                    <div class="info-title chat-icon">Discord</div>
                    <div class="info-details"><p>Geri Dönüş Süresi</p><small>Genellikle 10 Dakika</small>

                </div>
                <div class="btn-holder">
                        <a href="https://discord.gg/GKkupyHRTj" class="ybtn ybtn-accent-color"><i class="fab fa-discord" style="margin-right: 5px;"></i> Discord Sunucumuz</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box">
                    <div class="info-title chat-icon">E-Posta</div>
                    <div class="info-details"><p>Geri Dönüş Süresi</p><small>Genellikle 2 Saat</small>

                    <p><a href="mailto:destek@oculeth.com">destek@oculeth.com</a></p>
                </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box">
                    <div class="info-title location-icon">Destek Sistemi</div>
                    <div class="info-details"><p>Geri Dönüş Süresi</p><small>Genellikle 15 Dakika</small>


                    </div>
                    <div class="btn-holder">
                        <a href="/panel/submitticket.php" class="ybtn ybtn-accent-color">Talep Oluştur</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('static/footer.php');
?>