<?php 
if(!isset($action[1])){
    $action[0] = "404";
}
    
?>
<?php
include('static/header.php');
?>


<?php if(isset($action[1]) && $action[1] == "cpanel"):?>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">cPanel Hosting</div>
                    <div id="page-icon">
                        <div class="pricing-icon">
                            <img src="/<?=$realPath?>/assets/images/aicon4.png" alt="" style="border-radius: 0px;">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="info-text grey-text">Türkiye'nin en büyük sunucularına ev sahipliği yapan kaliteli hizmet ve yüksek performansı amaçlayan cPanel Sunucu Kiralama adresine hoşgeldiniz, firmamız üzerinden en kaliteli cPanel Hostingi en ucuza kiralayabilirsiniz.</div>
            </div>
        </div>
    </div>
</div> 
<div id="pricing" class="container-fluid">
    <div class="container">
        <div class="row">
                    <?php foreach ($productsWebhost as $key => $readProducts): $key = $key+1; ?>
            <div class="col-sm-6 col-md-3">

                <div class="pricing-box pricing-box-simple pricing-color1">
                    <div class="pricing-content">

                        <div class="pricing-head">
                        <div style="height: 32px;">
                                <img src="/<?=$realPath?>/assets/images/aicon4.png" style="height: 60px; padding-bottom: 20px;">
                            </div>
                            <div class="pricing-title">Paket-<?=$key?></div>

                            <div class="pricing-options">
                                <div class="tab-content">
                                    <div id="monthly1" class="tab-pane fade in active">
                                        <div class="pricing-price"><?=$readProducts['price']?></div>
                                        <div class="billing-cycle"> / Yıllık</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pricing-details">
                            <ul>
                                <li><?=$readProducts['domain']?> Domain Barındırma</li>
                                <li><?=$readProducts['ram']?> Ram</li>
                                <li><?=$readProducts['disk']?> Disk</li>
                                <li><?=$readProducts['traffic']?> Trafik</li>
                                <li>Türkiye Lokasyon</li>
                                <li>%99 DDOS Koruması</li>
                                <li>SSO Tek Tıkla Giriş Yap</li>
                                <li>cPanel Yönetim Paneli</li>
                            </ul>
                        </div>
                        <div class="pricing-link">
                            <a class="ybtn" href="<?=$readProducts['link']?>">Hemen Satın Al</a>
                        </div>
                    </div>
                </div>

            </div>
            <?php endforeach;?>

        </div>
    </div>
</div>
<?php elseif(isset($action[1]) && $action[1] == "reseller"):?>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="page-title">Reseller Hosting</div>
                    <div id="page-icon">
                        <div class="pricing-icon">
                            <img src="/<?=$realPath?>/assets/images/aicon3.png" alt="" style="border-radius: 0px;">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div id="h-info" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="info-text grey-text">Türkiye'nin en büyük sunucularına ev sahipliği yapan kaliteli hizmet ve yüksek performansı amaçlayan cPanel Sunucu Kiralama adresine hoşgeldiniz, firmamız üzerinden en kaliteli cPanel Reselleri en ucuza kiralayabilirsiniz.</div>
            </div>
        </div>
    </div>
</div> 
<div id="pricing" class="container-fluid">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="info-text grey-text">Bir zaman makinesine sahip değilseniz bu sayfayı görüntüleyemezsiniz. (404) bip bop.<br>Ana sayfaya dönmek için tıklayın.</div>
                <div class="btn-holder">
                    <a href="/anasayfa" class="ybtn ybtn-accent-color ybtn-shadow">Ana Sayfa</a>
                </div>
            </div>


        </div>
    </div>
</div>
<?php else:?>
    <?php header('Location: /404');?>
<?php endif;?>
<?php
include('static/footer.php');
?>