<?php
include('static/header.php');
?>
    <div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center">
                    <div class="icons-animation-holder">
                        <div class="aicon aicon1"><img src="/<?=$realPath?>/assets/images/aicon1.png" alt=""></div>
                        <div class="aicon aicon2"><img src="/<?=$realPath?>/assets/images/aicon2.png" alt=""></div>
                        <div class="aicon aicon3"><img src="/<?=$realPath?>/assets/images/aicon3.png" alt=""></div>
                        <div class="aicon aicon4"><img src="/<?=$realPath?>/assets/images/aicon4.png" alt=""></div>
                        <div class="aicon aicon-main">
                            <img src="/<?=$realPath?>/assets/images/oculeth-light.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 company-info-holder">
                    <h4>Hakkımızda</h4>
                    <div class="info-slider">
                        <div>
                            <div class="details-holder">
                                <p>Firmamız, Oyun Sunucusu Hizmetleri sunabilmek amacıyla 2021 yılında İzmir'de kurulmuştur. Kurulduğu günden itibaren müşterilerine kesintisiz, hızlı ve güvenilir internet hizmetleri sunmayı ve eksiksiz müşteri memnuniyetini amaç edinmiştir.</p>
                            </div>
                        </div>
                        <div>
                            <div class="details-holder">
                                <p>Firmamızın amacı oyun pazarında iddialı bir konuma gelebilmek, pazar payını en üst seviyelere çıkarmak ve Türkiye'de oyun sunucusu denilince akla gelen ilk isim olmaktır.</p>
                            </div>
                        </div>
                        <div>
                            <div class="details-holder">
                                <p>						Hizmetlerimizin kalitesini korumak ve geliştirmek için daima yenilikleri takip etmekte ve yeniliklere ayak uydurmaktayız. En iyi hizmeti verebilmek için en iyilerle çalışılması gerekir. Bu nedenle birlikte çalışmakta olduğumuz iş ortakları ve tedarikçi firmalar konusunda da çok titiz davranmaktayız. Hizmetlerimiz size sektörünün en iyi yazılım, en iyi donanım ve en iyi internet çıkışlarıyla sunulmaktadır.
</p>
                            </div>
                        </div>
                        <div>
                            <div class="details-holder">
                            <p>Oculeth.com olarak kaliteden taviz vermeden siz müşterilerimize en iyi hizmeti vermeye devam edeceğiz. Bize güvenebilirsiniz. 
                            </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('static/work.php');?>
<?php include('static/team.php');?>
<?php
include('static/footer.php');
?>