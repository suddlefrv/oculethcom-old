<div id="team" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row-title">Takımımız</div>
                <div class="row-subtitle"></div>
            </div>
        </div>
        <div class="row team-holder">
            <?php foreach($team as $rteam):?>
            <div class="col-sm-6 col-md-3">

                <div class="person-box">
                    <div class="person-icon">
                        <div class="person-img"><img src="<?=$rteam["pp"]?>" alt="" /></div>
                    </div>
                    <div class="person-name"><?=$rteam["isim"]?></div>
                    <div class="person-title"><?=$rteam["rank"]?></div>
                    <div class="person-social">
                        <a href="<?=$rteam["twitter"]?>"><i class="fab fa-twitter"></i></a>
                        <a href="<?=$rteam["instagram"]?>"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
        </div>
    </div>
</div>