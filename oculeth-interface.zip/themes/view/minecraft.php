<?php include('static/header.php');?>
<div id="page-head" class="container-fluid inner-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <?php if(!isset($action[1])):?>
                    <div class="page-title">Minecraft Standart</div>
                    <?php elseif(isset($action[1]) && $action[1] == "premium"):?>
                    <div class="page-title">Minecraft Premium</div>
                    <?php endif;?>
                    <div id="page-icon">
                        <div class="pricing-icon">
                            <?php if(!isset($action[1])):?>
                            <img src="/<?=$realPath?>/assets/images/odun1.png" alt="" style="border-radius: 0px;">
                            <?php elseif(isset($action[1]) && $action[1] == "premium"):?>
                            <img src="/<?=$realPath?>/assets/images/odun7.png" alt="" style="border-radius: 0px;">
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="pricing" class="container-fluid">
    <div class="container">
        <div class="row">
        <?php if(!isset($action[1])):?>
                    <?php foreach ($productsBasic as $key => $readProducts): $key = $key+1; ?>
            <div class="col-sm-6 col-md-3">

                <div class="pricing-box pricing-box-simple pricing-color1">
                    <div class="pricing-content">

                        <div class="pricing-head">
                        <div style="height: 64px;">
                                <img src="<?=$readProducts['image']?>">
                            </div>
                            <div class="pricing-title">Paket-<?=$key?></div>

                            <div class="pricing-options">
                                <div class="tab-content">
                                    <div id="monthly1" class="tab-pane fade in active">
                                        <div class="pricing-price"><?=$readProducts['price']?></div>
                                        <div class="billing-cycle"> / Aylık</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pricing-details">
                            <ul>
                                <li><?=$readProducts['cpu']?> E5-26XX v2 İşlemci</li>
                                <li><?=$readProducts['ram']?> DDR3 Ram</li>
                                <li><?=$readProducts['disk']?> NVMe SSD</li>
                                <li>Limitsiz Trafik</li>
                                <li>Türkiye Lokasyon</li>
                                <li>%99 DDOS Koruması</li>
                            </ul>
                        </div>
                        <div class="pricing-link">
                            <a class="ybtn" href="<?=$readProducts['link']?>">Hemen Satın Al</a>
                        </div>
                    </div>
                </div>

            </div>
            <?php endforeach;?>
            <?php elseif(isset($action[1]) && $action[1] == "premium"):?>
                <?php foreach ($products as $key => $readProducts): $key = $key+1; ?>
                <div class="col-sm-6 col-md-3">

<div class="pricing-box pricing-box-simple pricing-color1">
    <div class="pricing-content">

        <div class="pricing-head">
        <div style="height: 64px;">
                <img src="<?=$readProducts['image']?>">
            </div>
            <div class="pricing-title">Paket-<?=$key?></div>

            <div class="pricing-options">
                <div class="tab-content">
                    <div id="monthly1" class="tab-pane fade in active">
                        <div class="pricing-price"><?=$readProducts['price']?></div>
                        <div class="billing-cycle"> / Aylık</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pricing-details">
            <ul>
                <li><?=$readProducts['cpu']?> Ryzen 9 5950X İşlemci</li>
                <li><?=$readProducts['ram']?> DDR4 Ram</li>
                <li><?=$readProducts['disk']?> NVMe SSD</li>
                <li>Limitsiz Trafik</li>
                <li>Türkiye Lokasyon</li>
                <li>%99 DDOS Koruması</li>
            </ul>
        </div>
        <div class="pricing-link">
            <a class="ybtn" href="<?=$readProducts['link']?>">Hemen Satın Al</a>
        </div>
    </div>
</div>

</div>
                <?php endforeach;?>
            <?php endif;?>

        </div>
    </div>
</div>
<?php include('static/footer.php');?>