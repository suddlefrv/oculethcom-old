<?php


$customer = array(
					
    array(
        'user' => 'UrfaKebab.yml',
        'img' => 'https://cdn.discordapp.com/attachments/914081417401622588/954433618514698321/57e119f258468a9e2feab8b623e2909e.webp',
        'rank' => 'Müşteri',
        'comment' => 'Oculeth kanatlandırır...'
    ),
    array(
        'user' => '[ Yağız ]',
        'img' => 'https://cdn.discordapp.com/attachments/914081417401622588/954434683230380124/a_4c4fad1fdecde70e6f4fce77e8ec7563.gif',
        'rank' => 'Müşteri',
        'comment' => 'Yeni kullanmaya başladık şu anda pek bilgili değiliz fakat şu anlık şunları söyleyebileceğim. İnternet hızı çok güzel kaliteli vds kasmıyor üstte yorumlardada arkadaşlar güzel yorumlar yapmış demekki güzel buradan anlayabiliriz :)'
    ) 

);



$realPath = "themes/oculeth/";

$productsBasic = array( 
 

    array(
        'ram' => '16 GB',
        'firstprice' => '114.99₺',
        'price' => '124.99₺',
        'disk' => '160 GB',
        'cpu' => '12x',
        'image' => "/" .$realPath . "/assets/images/odun4.png",
        'link' => 'https://oculeth.com/panel/siparis/server/106'
    )

);

$products = array(

    array(
        'ram' => '8 GB',
        'firstprice' => '237.99₺',
        'price' => '149.99₺',
        'disk' => '80 GB',
        'cpu' => '5x',
        'image' => "/" .$realPath . "/assets/images/odun6.png",
        'link' => 'https://oculeth.com/panel/siparis/server/108'
    ) 

);
$productsWebhost = array(
    
    array(
        'image' =>'https://cdn.discordapp.com/attachments/914076514885201931/951548900425207808/server-icon-png-7-Transparent-Images.png',
        'ram' => '1 GB',
        'domain' => '1',
        'disk' => '15 GB',
        'price' => '7.50₺',
        'traffic' => '15 GB',
        'link' =>'https://oculeth.com/panel/siparis/hosting/115'
    ),
    array(
        'image' =>'https://cdn.discordapp.com/attachments/914076514885201931/951548900425207808/server-icon-png-7-Transparent-Images.png',
        'ram' => '2 GB',
        'domain' => '2',
        'disk' => '30 GB',
        'price' => '12.50₺',
        'traffic' => '30 GB',
        'link' =>'https://oculeth.com/panel/siparis/hosting/116'
    ),
    array(
        'image' =>'https://cdn.discordapp.com/attachments/914076514885201931/951548900425207808/server-icon-png-7-Transparent-Images.png',
        'ram' => '3 GB',
        'domain' => '3',
        'disk' => 'Sınırsız',
        'price' => '14.99₺',
        'traffic' => '35 GB',
        'link' =>'https://oculeth.com/panel/siparis/hosting/117'
    ),
    array(
        'image' =>'https://cdn.discordapp.com/attachments/914076514885201931/951548900425207808/server-icon-png-7-Transparent-Images.png',
        'ram' => '3 GB',
        'domain' => '5',
        'disk' => 'Sınırsız',
        'price' => '19.99₺',
        'traffic' => 'Sınırsız',
        'link' =>'https://oculeth.com/panel/siparis/hosting/118'
    ),
    
);
$team = array(
    array(
        'pp' => "/" . $realPath . '/assets/images/team1.jpg',
        'isim' => 'Samet Turan',
        'rank' => 'System Administrator',
        'instagram' => '',
        'twitter' => ''
    )
);
?>