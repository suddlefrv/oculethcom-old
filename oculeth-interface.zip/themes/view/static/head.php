<!doctype html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<title>Oculeth - Türkiye'nin En Büyük Oyun Sunucu Sağlayıcısı.</title>
  <link rel="icon" type="image/x-icon" href="https://media.discordapp.net/attachments/914076514885201931/960234159907954738/discord-dark-removebg-preview.png">
<meta name="description" content="Türkiye'nin en büyük oyun sunucusu ve web hosting sağlayıcısı olarak her gün gelişerek yeni teknolojilerle gücümüze güç katıyoruz.">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/bootstrap-slider.min.css">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/fontawesome-all.min.css">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/slick.css">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/style-darkblue.css">
<link rel="stylesheet" type="text/css" href="/<?=$realPath?>/assets/css/custom.css">
</head>
<body>
